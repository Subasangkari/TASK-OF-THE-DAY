package com.myapp.service;

import java.util.ArrayList;
import java.util.Date;

import com.myapp.dao.BookDao;
import com.myapp.model.Book;
import com.myapp.model.Distributor;
import com.myapp.model.Publisher;

public class BookService {

	public static void main (String[] args) {
		/*Book book=new Book(103,"Deathly Hallows","J.K.ROWLING",new Date());
		book.setCopiesOfBook(10);
		
		Publisher publisher1=new Publisher("XYZ Publication","4");
		book.setPublisher1(publisher1);
		Publisher publisher=new Publisher("ABC Publication","3");
		book.setPublisher(publisher);
		
		
		ArrayList<Distributor>distList=new ArrayList();
		distList.add(new Distributor(1,"John","Bang") );
		distList.add(new Distributor(2,"cena","mum"));
		book.setDistList(distList);
		
		BookDao dao=new BookDao();
		//dao.saveBook(book);
		System.out.println(dao.saveBook(book));
		*/
		
		/*BookDao dao=new BookDao();
		Book book=dao.getBook(103);
		System.out.println(book);
		*/
		/*BookDao dao=new BookDao();
		ArrayList<Book> books =(ArrayList<Book>) dao.getAllBooks();
		for(Book book:books) {
			System.out.println(book);
			}
*/		
		/*BookDao dao= new BookDao();
		Book book=dao.getBookByTitle("HARRY POTTER AND CHAMBERS OF SECRETS");
		System.out.println(book);
		*/
		BookDao dao=new BookDao();
		 ArrayList<Book> books=(ArrayList<Book>)dao.filterBooks();

		 for(Book book1:books){
		 System.out.println(book1);
		 }

	}
}
