package com.myapp.model;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Publisher {

	private String publisherName;
	//@AttributeOverrides(@AttributeOverride(name="publisherName1",column=@Column(name="publisherName")))
	@Column(name="publisherName" ,insertable=false,updatable=false)
	private String publisherName1;

	private String publisherId;
	//@AttributeOverrides(@AttributeOverride(name="publisherId1",column=@Column(name="publisherId")))
	@Column(name="publisherId" ,insertable=false,updatable=false)
	private String publisherId1;
	
	public String getPublisherName() {
		return publisherName;
	}
	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}
	
	public String getPublisherId() {
		return publisherId;
	}
	public void setPublisherId(String publisherId) {
		this.publisherId = publisherId;
	}
	public Publisher(String publisherName, String publisherId) {
		super();
		this.publisherName = publisherName;
		this.publisherId = publisherId;
	}
	public Publisher() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Publisher [publisherName=" + publisherName + ", publisherId=" + publisherId + "]";
	}
	
}
