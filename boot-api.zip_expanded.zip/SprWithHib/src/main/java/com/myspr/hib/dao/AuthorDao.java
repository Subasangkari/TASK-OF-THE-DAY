package com.myspr.hib.dao;


import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.myspr.hib.Model.Author;
@Transactional
public class AuthorDao {
	@Autowired
	SessionFactory factory;
	public AuthorDao() {
		// TODO Auto-generated constructor stub
	}
	public AuthorDao(SessionFactory factory) {
		super();
		this.factory = factory;
		}
	public String saveAuthor(Author author){
		try{
		Session session=factory.getCurrentSession();
		session.save(author);
		return "Author Created";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}

		return "cannot create Author";
		}
	
	public Author getAllAuthorByName(String authorName)
	{
			try
	{
	Session session=factory.getCurrentSession();
	
	Query query=session.createQuery("from Author c where c.authorName=:authorName");
	query.setParameter("authorName",authorName);
	Author author=(Author)query.list().get(0);
    return author;
	}
	catch (Exception e) {
	e.printStackTrace();
	}
	return null;
	}
	public Author getAllAuthorByCity(String authorCity)
	{
	try
	{
	Session session=factory.getCurrentSession();
	
	Query query=session.createQuery("from Author c where c.authorCity=:authorCity");
	query.setParameter("authorCity",authorCity);
	Author author=(Author)query.list().get(0);
    return author;
	}
	catch (Exception e) {
	e.printStackTrace();
	}
	return null;
	}
	
	public String deleteAuthor(String authorName){
		try{
		Session session=factory.getCurrentSession();
		String sql="delete from Author a where a.authorName=:authorName";
        Query query=session.createQuery(sql);
        query.setParameter("authorName", authorName);
        int res=query.executeUpdate();
        if(res>0)
		return "Author Deleted";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}

		return "cannot delete Author";
		}
	public Author getAuthorById(int authorId){
		try{
		Session session=factory.getCurrentSession();
		Author author=(Author)session.get(Author.class,authorId);
		return author;
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}

		return null;
		}



		public String updateAuthorById(Author author){
		try{
		Session session=factory.getCurrentSession();

		System.out.println("author "+author);
		session.update("Author",author);
		return "Author Updated";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}

		return "Cannot Update Auhtor";
		}


}
