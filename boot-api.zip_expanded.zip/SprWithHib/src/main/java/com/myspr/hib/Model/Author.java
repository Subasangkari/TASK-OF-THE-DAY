package com.myspr.hib.Model;
import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Author {
	@Id
	int authorId;
	String authorName;
	String authorCity;
	public Author(int authorId, String authorName, String authorCity) {
		super();
		this.authorId = authorId;
		this.authorName = authorName;
		this.authorCity = authorCity;
		}
	public String getAuthorCity() {
		return authorCity;
	}
	public void setAuthorCity(String authorCity) {
		this.authorCity = authorCity;
	}
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public Author() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Author [authorId=" + authorId + ", authorName=" + authorName + ", authorCity=" + authorCity
				+ "]";
	}
	
}
