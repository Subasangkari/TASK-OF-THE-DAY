package com.myspr.demo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.myspr.demo.Model.Product1;
import com.myspr.demo.dao.Product1Dao;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	//YYYY/MM/DD
	SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
	binder.registerCustomEditor(Date.class, new CustomDateEditor(df, false));
	}

	@Autowired
	Product1Dao dao;
	@RequestMapping(value="/")
	public String home(Model model)
	{
	return "home";
	}

	@RequestMapping(value="/display")
	public String display(Model model,@ModelAttribute Product1 product)
	{
	String status=dao.saveProduct(product);
	model.addAttribute("status",status);
	return "display";
	}

	@RequestMapping(value="/displayProductByName")
	public String displayAuthorByName(Model model,@RequestParam("productName") String productName)
	{
		System.out.println(productName);
		Product1 product=dao.getAllProductByName(productName);
		System.out.println(product);
		model.addAttribute("product",product);
     return "displayProductByName";
	}
	
	@RequestMapping(value="/displayDeletedProduct")
	public String deleteAuthor(Model model,@ModelAttribute("productName") String productName)
	{
	String status=dao.deleteProduct(productName);
	model.addAttribute("status",status);
	return "display";
	}
   
   @RequestMapping(value="/updatePage")
   public String update()
   {
   return "updatePage";
   }

   int productId=0;
   @RequestMapping(value="/searchForUpdate")
   public String searchForUpdate(Model model,@RequestParam("productId") String productId)
   {
   int prodId=Integer.parseInt(productId);
   this.productId=prodId;
   Product1 product=dao.getProductById(prodId);
   System.out.println(product);
   model.addAttribute(product);
   return "updatePage";
   }

   @RequestMapping(value="/updateData")
   public String updateData(@ModelAttribute Product1 product)
   {
   product.setProductId(productId);
   System.out.println(product);
   dao.updateProductById(product);
   System.out.println(product);
   return "updatePage";
   }
   
	
}
