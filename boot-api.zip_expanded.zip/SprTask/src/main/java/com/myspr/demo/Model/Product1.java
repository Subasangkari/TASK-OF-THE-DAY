package com.myspr.demo.Model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product1 {
	@Id
	int productId;
	String productName;
	String productPrice;
	Date mfg;
	Date exp;
	public Product1() {
		// TODO Auto-generated constructor stub
	}
	public String getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Date getMfg() {
		return mfg;
	}
	public void setMfg(Date mfg) {
		this.mfg = mfg;
	}
	public Date getExp() {
		return exp;
	}
	public void setExp(Date exp) {
		this.exp = exp;
	}
	public Product1(int productId, String productName, String productPrice, Date mfg, Date exp) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.mfg = mfg;
		this.exp = exp;
	}
	@Override
	public String toString() {
		return "Product1 [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", mfg=" + mfg + ", exp=" + exp + "]";
	}
}
