package com.myspr.demo.dao;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import com.myspr.demo.Model.Product1;

@Transactional
public class Product1Dao {
	@Autowired
	SessionFactory factory;
	public Product1Dao() {
		// TODO Auto-generated constructor stub
	}
	
	public Product1Dao(SessionFactory factory) {
		super();
		this.factory = factory;
		}
	
	public String saveProduct(Product1 product){
		try{
		Session session=factory.getCurrentSession();
		session.save(product);
		return "Product Created";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}

		return "cannot create Product";
		}
	
	public Product1 getAllProductByName(String productName)
	{
	try
	{
	Session session=factory.getCurrentSession();
	Query query=session.createQuery("from Product1 c where c.productName=:productName");
	query.setParameter("productName",productName);
	Product1 product=(Product1)query.list().get(0);
    return product;
	}
	catch (Exception e) {
	e.printStackTrace();
	}
	return null;
	}
	
	public String deleteProduct(String productName){
		try{
		Session session=factory.getCurrentSession();
		String sql="delete from Product1 a where a.productName=:productName";
        Query query=session.createQuery(sql);
        query.setParameter("productName", productName);
        int res=query.executeUpdate();
        if(res>0)
		return "Product Deleted";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
        return "cannot delete Product";
		}

	public Product1 getProductById(int productId){
		try{
		Session session=factory.getCurrentSession();
		Product1 product=(Product1)session.get(Product1.class,productId);
		return product;
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
		return null;
		}
	
	public String updateProductById(Product1 product){
		try{
		Session session=factory.getCurrentSession();
		System.out.println("product"+product);
		session.update("Product1",product);
		return "product Updated";
		}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		}
		return "Cannot Update product";
		}
	
}