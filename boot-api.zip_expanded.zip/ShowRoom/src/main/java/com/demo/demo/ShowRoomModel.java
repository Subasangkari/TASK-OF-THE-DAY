package com.demo.demo;
import java.util.ArrayList;

import com.demo.demo.CarModel;
public class ShowRoomModel {
String showroom_Name;
ArrayList<CarModel>cars;
public String getShowroom_Name() {
	return showroom_Name;
}
public void setShowroom_Name(String showroom_Name) {
	this.showroom_Name = showroom_Name;
}
public ArrayList<CarModel> getCars() {
	return cars;
}
public void setCars(ArrayList<CarModel> cars) {
	this.cars = cars;
}
public ShowRoomModel(String showroom_Name, ArrayList<CarModel> cars) {
	super();
	this.showroom_Name = showroom_Name;
	this.cars = cars;
}
public ShowRoomModel() {
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "ShowRoomModel [showroom_Name=" + showroom_Name + ", cars=" + cars + "]";
}
}
