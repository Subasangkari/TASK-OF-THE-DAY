package com.demo.demo;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home() {
		return "home";
	}
	String showroom_Name="";

	@RequestMapping(value = "/addCars", method = RequestMethod.GET)
	public String addCars(@RequestParam ("showroom_Name") String showroom_Name) {

	this.showroom_Name=showroom_Name;
	return "addCars";
	}

	ArrayList<CarModel> cars=new ArrayList<CarModel>();

	@RequestMapping(value = "/addCars2", method = RequestMethod.GET)
	public String addCars2(@ModelAttribute CarModel car) {

	cars.add(car);
	return "addCars";
	}
	@RequestMapping(value = "/displayCars",method = RequestMethod.GET)
	public String DisplayCar(Model model) {
		ShowRoomModel showroom=new ShowRoomModel(showroom_Name,cars);
		model.addAttribute("showroom",showroom);
		return "displayCars";
	}	
}
