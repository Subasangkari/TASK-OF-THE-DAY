package com.demo.demo;

public class CarModel {
String car_Name;
String car_brand;
String car_Color;
public String getCar_Name() {
	return car_Name;
}
public void setCar_Name(String car_Name) {
	this.car_Name = car_Name;
}
public String getCar_brand() {
	return car_brand;
}
public void setCar_brand(String car_brand) {
	this.car_brand = car_brand;
}
public String getCar_Color() {
	return car_Color;
}
public void setCar_Color(String car_Color) {
	this.car_Color = car_Color;
}
public CarModel(String car_Name, String car_brand, String car_Color) {
	super();
	this.car_Name = car_Name;
	this.car_brand = car_brand;
	this.car_Color = car_Color;
}
public CarModel() {
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "CarModel [car_Name=" + car_Name + ", car_brand=" + car_brand + ", car_Color=" + car_Color + "]";
}


}
