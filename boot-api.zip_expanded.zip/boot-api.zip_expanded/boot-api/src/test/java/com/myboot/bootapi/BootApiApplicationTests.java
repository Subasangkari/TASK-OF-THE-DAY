package com.myboot.bootapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
