package com.myboot.bootapi;

public class Student {
 int studId;
 String studentName;
public int getStudId() {
	return studId;
}
public void setStudId(int studId) {
	this.studId = studId;
}
public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
public Student(int studId, String studentName) {
	super();
	this.studId = studId;
	this.studentName = studentName;
}
 public Student() {
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Student [studId=" + studId + ", studentName=" + studentName + "]";
}
 
}
