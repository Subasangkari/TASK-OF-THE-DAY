package com.myboot.mvc;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.myboot.mvc.dao.MyUsersDao;
import com.myboot.mvc.model.MyUsers;

@Controller
public class HomeController {
	@Autowired
	MyUsersDao dao;

	@RequestMapping(value="/test")
	public String home()
	{
	dao.saveUser(new MyUsers("xyz","0109"));
	return "home";
	}
	@RequestMapping(value="/displayUsers")
	public String displayUsers(Model model)
	{
		ArrayList<MyUsers> users=(ArrayList<MyUsers>)dao.getAllUsers();
		model.addAttribute("users",users);
		System.out.println(users);
		return "displayUserByName";
	}
	

}
