package com.myboot.mvc.dao;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.myboot.mvc.model.MyUsers;

@Component
@Transactional

public class MyUsersDao {
	@Autowired
	SessionFactory sessionFactor;


	public String saveUser(MyUsers myUsers)
	{
	try
	{
	Session session=sessionFactor.getCurrentSession();
	session.save(myUsers);

	return "user created";
	}
	catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
	}

	return "cannot create user";

	}
	public List<MyUsers> getAllUsers()
	{
	try
	{
	Session session=sessionFactor.getCurrentSession();
	Query query=session.createQuery("select a from MyUsers a"); 
	System.out.println(query);
	ArrayList<MyUsers> users=(ArrayList<MyUsers>)query.list();
	//System.out.println(users);
    return users;
	}
	catch (Exception e) {
	e.printStackTrace();
	}
	return null;
	}
	

}
