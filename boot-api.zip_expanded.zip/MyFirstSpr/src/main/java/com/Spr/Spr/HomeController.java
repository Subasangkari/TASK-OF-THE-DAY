package com.Spr.Spr;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.Spr.Spr.Student;

@Controller
public class HomeController {

@RequestMapping(value = "/")
public String home() {
return "home";
}


@RequestMapping(value="display")
public String myMeth2(Model model,@ModelAttribute Student student)
{
	model.addAttribute("student",student);
return "design";
}
}







/*
 * import java.text.DateFormat; import java.util.Date; import java.util.Locale;
 * import java.util.Map; import java.util.Set;
 * 
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.ui.Model; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestMethod; import
 * org.springframework.web.bind.annotation.RequestParam;
 * 
 * 
 * 
 * @Controller public class HomeController {
 * 
 * @RequestMapping(value = "/") public String home() { return "home"; }
 * 
 * 
 * @RequestMapping(value="display") public String myMeth2(Model
 * model,@RequestParam() Map<String,String> params) {
 * 
 * 
 * String name= params.get("uname"); String studentId=params.get("studId");
 * String address=params.get("studAddress"); int
 * sem=Integer.parseInt(params.get("studSem"));
 * 
 * 
 * Student student=new Student(name, studentId, address, sem);
 * 
 * 
 * model.addAttribute("student",student); return "design"; } }
 */


/*
 * import java.text.DateFormat; import java.util.Date; import java.util.Locale;
 * import java.util.Map; import java.util.Set;
 * 
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.ui.Model; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestMethod; import
 * org.springframework.web.bind.annotation.RequestParam;
 * 
 * @Controller public class HomeController {
 * 
 * @RequestMapping(value = "/") public String home(Locale locale, Model model) {
 * 
 * Date date=new Date(); model.addAttribute("test", date );
 * 
 * return "design"; }
 * 
 * 
 * @RequestMapping(value = "/test") public String myMeth() { return "design"; }
 * 
 * @RequestMapping(value="mypage") public String myMeth2(Model model) { String
 * msg="msg from mymeth 2"; model.addAttribute("msg",msg); return "display"; }
 * 
 * @RequestMapping(value="display") public String myMeth2(Model
 * model,@RequestParam() Map<String,String> params) {
 * 
 * 
 * Set<String> keys= params.keySet();
 * 
 * 
 * for(String key:keys) {
 * 
 * System.out.println(params.get(key)); }
 * 
 * model.addAttribute("params",params); return "design"; } }
 *//*
 * 
 * @RequestMapping(value = "/") public String home(Locale locale, Model model) {
 * 
 * Date date=new Date(); model.addAttribute("test", date );
 * 
 * return "home"; }
 * 
 * 
 * @RequestMapping(value = "/test") public String myMeth() { return "home"; }
 * 
 * @RequestMapping(value="mypage") public String myMeth2(Model model) { String
 * msg="msg from mymeth 2"; model.addAttribute("msg",msg); return "display"; }
 * 
 * }
 * 
 */
/*
 * package com.Spr.Spr; import java.text.DateFormat; import java.util.Date;
 * import java.util.Locale;
 * 
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.ui.Model; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestMethod;
 * 
 * 
 * @Controller public class HomeController {
 * 
 * @RequestMapping(value = "/") public String home(Locale locale, Model model) {
 * 
 * Date date=new Date(); model.addAttribute("test", date );
 * 
 * return "home"; }
 * 
 * }
 * 
 */

/*
 * import java.text.DateFormat; import java.util.Date; import java.util.Locale;
 * 
 * import org.slf4j.Logger; import org.slf4j.LoggerFactory; import
 * org.springframework.stereotype.Controller; import
 * org.springframework.ui.Model; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestMethod;
 * 
 *//**
	 * Handles requests for the application home page.
	 */
/*
 * @Controller public class HomeController {
 * 
 * private static final Logger logger =
 * LoggerFactory.getLogger(HomeController.class);
 * 
 *//**
	 * Simply selects the home view to render by returning its name.
	 *//*
		 * @RequestMapping(value = "/", method = RequestMethod.GET) public String
		 * home(Locale locale, Model model) {
		 * logger.info("Welcome home! The client locale is {}.", locale);
		 * 
		 * Date date = new Date(); DateFormat dateFormat =
		 * DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		 * 
		 * String formattedDate = dateFormat.format(date);
		 * 
		 * model.addAttribute("serverTime", formattedDate );
		 * 
		 * return "home"; }
		 * 
		 * }
		 */