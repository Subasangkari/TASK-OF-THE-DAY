package com.myapp.model;

import java.util.Date;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity 
public class Book {

	@Id
	private int isbn;
	private String title;
	private String author;
	//@Column(name="book_date")
	private Date dob;
	/*
	@Transient
	int copiesOfBook;
	
	Publisher publisher;
	@Embedded

	@AttributeOverrides({
		@AttributeOverride
		(name="publisherName",column=@Column(name="publisherName1",insertable=false,updatable=false)),
	
		@AttributeOverride
			(name="publisherId",column=@Column(name="publisherId1",insertable=false,updatable=false))
	})

	Publisher publisher1;
		   
	
	public Publisher getPublisher1() {
		return publisher1;
	}
	public void setPublisher1(Publisher publisher1) {
		this.publisher1 = publisher1;
	}
	@ElementCollection
	List<Distributor> distList;


	public List<Distributor> getDistList() {
	return distList;
	}
	public void setDistList(List<Distributor> distList) {
	this.distList = distList;
	}
	
	@Embedded

	@AttributeOverrides({
		@AttributeOverride
		(name="publisherName",column=@Column(name="publisherName1")),
	
		@AttributeOverride
			(name="publisherId",column=@Column(name="publisherId1"))
	})
	public Publisher getPublisher() {
		return publisher;
	}
	public void setPublisher(Publisher publisher) {
		this.publisher = publisher;
	}
	public int getCopiesOfBook() {
		return copiesOfBook;
	}
	public void setCopiesOfBook(int copiesOfBook) {
		this.copiesOfBook = copiesOfBook;
	}
*/	public Date getDob() {
		return dob;
	}
	public void setDate(Date dob) {
		this.dob = dob;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Book(int isbn, String title, String author) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.author = author;
	}
	public Book() {
		// TODO Auto-generated constructor stub
	}
	public Book(int isbn, String title, String author, Date dob) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.dob = dob;
	}
	
	/*public Book(int isbn, String title, String author, Date date, int copiesOfBook, Publisher publisher,
			Publisher publisher1, List<Distributor> distList) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.date = date;
		this.copiesOfBook = copiesOfBook;
		this.publisher = publisher;
		this.publisher1 = publisher1;
		this.distList = distList;
	}
*/	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", author=" + author + ", date=" + dob + "]";
	}}
