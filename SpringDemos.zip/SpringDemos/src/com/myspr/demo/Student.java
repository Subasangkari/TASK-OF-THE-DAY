package com.myspr.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Student {
	private int rollNo;
	private String name;
	private Address address;
	
	
	public Address getAddress() {
		return address;
	}
	@Qualifier("address2")
	@Autowired
	@Required
	public void setAddress(Address address) {
		this.address = address;
	}
	public int getRollNo() {
	return rollNo;
	}
	public void setRollNo(int rollNo) {
	this.rollNo = rollNo;
	}
	public String getName() {
	return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	
	public Student(int rollNo, String name, Address address) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.address = address;
	}
	//c1
	public Student( String name,int rollNo) {
	super();
	this.rollNo = rollNo;
	this.name = name;
	System.out.println("String name , int roll No");
	}

	//c2
	public Student(int rollNo, String name) {
	super();
	this.rollNo = rollNo;
	this.name = name;
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", address=" + address + "]";
	}

	public Student() {
	// TODO Auto-generated constructor stub
	}

}
