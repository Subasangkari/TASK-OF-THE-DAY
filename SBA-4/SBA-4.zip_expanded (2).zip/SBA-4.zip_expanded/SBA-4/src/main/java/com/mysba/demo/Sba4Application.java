package com.mysba.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sba4Application {

	public static void main(String[] args) {
		SpringApplication.run(Sba4Application.class, args);
	}

}
